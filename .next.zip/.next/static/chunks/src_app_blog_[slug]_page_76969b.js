(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_blog_[slug]_page_76969b.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_blog_[slug]_page_76969b.js",
  "chunks": [
    "static/chunks/src_d7d4d5._.js",
    "static/chunks/node_modules_moment_5ca364._.js",
    "static/chunks/node_modules_framer-motion_dist_es_3e6def._.js",
    "static/chunks/node_modules_axios_lib_c4c49c._.js",
    "static/chunks/node_modules_a82bc3._.js"
  ],
  "source": "dynamic"
});
