(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_76969b.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_76969b.js",
  "chunks": [
    "static/chunks/src_4f0c18._.js",
    "static/chunks/node_modules_a8fd64._.js",
    "static/chunks/node_modules_react-toastify_dist_ReactToastify_391de2.css"
  ],
  "source": "dynamic"
});
