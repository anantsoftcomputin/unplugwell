(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_layout_61af54.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_layout_61af54.js",
  "chunks": [
    "static/chunks/src_app_globals_b80590.css",
    "static/chunks/node_modules_54d056._.js",
    "static/chunks/src_44bfbd._.js"
  ],
  "source": "dynamic"
});
